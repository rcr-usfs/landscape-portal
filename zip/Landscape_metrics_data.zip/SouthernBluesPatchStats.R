################################################################################
# Written by: Carl Albury (calbury@fs.fed.us)
# Modified from code written by Carson Stam and Kim McCallum
# Last edited: September 2016
################################################################################


################################################################################
# User editable variables
# Define your inputs and outputs
################################################################################

# Note the double slashes in the pathname.
# For Windows the backslashes must be doubled.
workspace = "//166.2.126.25/rseat/Programs/GeoTASC/fy2017/Projects/R6-5_LandscapePatternTool/04_Data/02_Processed/outputs/"
classifiedRaster = "Malheur_2015_Classified_01_Nov_2017_141702.tif"

noDataValue = 0
runClassStats = "y"

################################################################################
# End user editable variables
################################################################################

outFile = gsub(".tif", "_patchStat.csv", classifiedRaster)
clOutfile = gsub(".tif", "_classStat.csv", classifiedRaster)
outRaster = gsub(".tif", "_patchRast.tif", classifiedRaster)

################################################################################
# install required packages
################################################################################
requiredPackages <- c("raster", "rgdal", "SDMTools")
toInstall <- requiredPackages[!(requiredPackages %in% installed.packages()[,"Package"])]
if(length(toInstall)) install.packages(toInstall)
################################################################################


################################################################################
# Main Script
################################################################################
# load libraries
library(raster)
library(rgdal)
library(SDMTools)

setwd(workspace)
outData <- NULL
timeStart=proc.time()
# define a simple matrix
# this is a simple matrix that can be used for testing
# tmat = { matrix(c( 255,255,255,2,1,1,2,2,1,2,
#                    1,1,2,1,2,1,1,1,1,1,
#                    1,2,NA,2,1,2,1,1,1,2,
#                    2,1,2,2,2,1,2,1,1,2,
#                    1,2,1,2,1,2,1,1,1,2,
#                    1,1,2,1,2,1,1,5,5,1,
#                    5,1,1,2,1,1,5,1,1,3,
#                    1,5,1,1,1,6,6,1,6,3,
#                    1,1,5,5,5,1,6,1,6,3,
#                    4,4,4,1,1,1,1,1,6,3),nr=10,byrow=TRUE) }
# 
# 
# r = raster(tmat)
r = raster(classifiedRaster)
# replace noData value with NA
r[r[]==noDataValue] = NA
r[r[]==255] = NA

# Create a raster of ones with the same dimensions as the input raster. 
# This raster will be used to hold patchID later.
patchRaster = r/r

# Get range of values in classified raster.
classes = unique(r)
if(tail(classes, 1)==255){
  classes = head(classes, -1)
}

print("Found classes:")
print(classes)

# Esatblish patchId incrementer. 
lastMaxPatchId = 0
# Loop through each class in classes
for(i in classes){
  print('***************************************')
  print(paste(i, "of", max(classes), sep = " "))
  
  #set up the single class matrix with i = 1 and all others = 0
  # set up reclassify matrix rclm   
  m = c(min(classes)-1,i-1,0,
        i,i,1,
        i+1,max(classes)+1,0)
  rclm = matrix(m, ncol=3, byrow=TRUE)
  

  rc = reclassify(r,rclm, right=NA)
  # Identify and number patches (connected-components) for a class i using ConnCompLabel
  patches = ConnCompLabel(rc)
  plot(patches, main = paste("patches", i, sep = " "))
  numPatches = maxValue(patches)
  print(paste("Number of patches: ", numPatches),sep = " ")
  print('***************************************')
  # Run Patch Stats on classs i
  paStat = PatchStat(patches, cellsize = 30,latlon = FALSE)
  # Remove patch zero row (pixels outside current class)
  paStat = paStat[!paStat$patchID == 0,]
  # add lastMaxPatchId to keep patcheIds incremented in table
  paStat$patchID = paStat$patchID + lastMaxPatchId
  stats = as.data.frame(paStat)
  stats = as.data.frame(append(i,stats))
  names(stats)[1] = 'Class'
  
  #add lastMaxPatchId to keep patcheIds incremented
  patches = (patches + lastMaxPatchId)*rc
  # prep for next run by substituting ones for zeros
  patches[patches==0] <- 1
  patchRaster = patchRaster * patches
  #print(as.matrix(patchRaster))
  #plot(patchRaster, main = 'patchRaster')
  # increment lastMaxPatchId
  lastMaxPatchId = max(paStat$patchID, na.rm=TRUE)
  
  if(is.null(outData)){
    outData = stats
  }
  else{
    outData = rbind(outData,stats)
  }
  # Gabage collection to keep memory impacts down
  gc()
}

plot(patchRaster, main = "Final patchRaster")
#print(as.matrix(patchRaster))
if(tolower(runClassStats)=="y"){
  clStats = ClassStat(r)}

write.csv(outData,outFile)
write.csv(clStats,clOutfile)
writeRaster(patchRaster, filename=outRaster, format="GTiff", datatype='INT4U', overwrite=TRUE)
print(proc.time()-timeStart)
# clean up all memory
rm(list=ls())
